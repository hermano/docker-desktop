#!/bin/bash

for ((;;))
do
    chromium-browser --start-maximized $1
done