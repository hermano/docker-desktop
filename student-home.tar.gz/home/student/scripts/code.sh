#!/bin/bash

for ((;;))
do
    LD_LIBRARY_PATH=$HOME/lib code $1
done