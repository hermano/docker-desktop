#!/bin/bash

echo "starting VNC server ..."
export USER=root
vncserver :1 -geometry 1366x768 -depth 24 
